# MOEX Data Loader

A comprehensive Python toolkit for downloading, processing, and analyzing futures data from the Moscow Exchange (MOEX). This project provides automated data collection, continuous contract construction, and visualization tools for MOEX futures markets.

## Features

- **Automated Data Collection**: Downloads historical futures data from MOEX API with robust error handling and retry mechanisms
- **Continuous Contract Construction**: Intelligently merges futures contracts based on volume analysis to create continuous price series
- **Data Visualization**: Generates summary plots and rollover analysis charts
- **Multiple Timeframes**: Supports 1-minute and 5-minute data aggregation
- **Progress Tracking**: Real-time progress bars and comprehensive logging

## Project Structure

```
moex_data_loader/
├── moex_futures_data_loader.py    # Main data downloader
├── moex_futures_merge.py          # Continuous contract construction
├── load_summary.py                # Data summary and visualization
├── update_data.py                 # Automated pipeline runner
├── utilities.py                   # Helper functions and utilities
├── requirements.txt               # Python dependencies
├── MOEX/                         # Raw futures data (CSV files)
├── continous/                    # Continuous contract data
└── summary/                      # Analysis plots and rollover data
```

## Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd moex_data_loader
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

## Usage

### Quick Start

Run the complete data pipeline:
```bash
python update_data.py
```

This will execute the following steps in sequence:
1. Download futures data (`moex_futures_data_loader.py`)
2. Generate data summaries (`load_summary.py`)
3. Create continuous contracts (`moex_futures_merge.py`)

### Individual Components

#### 1. Data Download
```bash
python moex_futures_data_loader.py
```
Downloads historical futures data for active tickers from MOEX. Features:
- Robust retry mechanism with exponential backoff
- Respectful API usage with random delays
- Automatic file existence checking to avoid re-downloads
- Progress tracking with detailed error reporting

#### 2. Data Summary
```bash
python load_summary.py
```
Generates visualization plots showing:
- Data availability by ticker and contract month
- Monthly vs quarterly contract classifications
- File size analysis for data quality assessment

#### 3. Continuous Contract Construction
```bash
python moex_futures_merge.py
```
Creates continuous futures contracts by:
- Analyzing volume patterns to determine optimal rollover dates
- Merging contracts based on liquidity analysis
- Generating both 1-minute and 5-minute continuous series
- Creating rollover analysis charts

## Configuration

### Supported Markets
- **Futures Market**: MOEX FORTS (Futures and Options on RTS)
- **Data Types**: OHLCV data with logarithmic returns
- **Timeframes**: 1-minute and 5-minute aggregations

### Contract Months
- **Monthly**: F, G, J, K, N, Q, V, X
- **Quarterly**: H, M, U, Z

### Date Ranges
- Default: 2022-2025 (configurable in `utilities.py`)
- Current focus: 2025 contracts (V, X, Z months)

## Data Output

### Raw Data (`MOEX/` folder)
- Individual CSV files for each futures contract
- Format: `{ticker}{month}{year}.csv`
- Columns: begin, open, high, low, close, volume, value, log_ret

### Continuous Data (`continous/` folder)
- `{ticker}_1min.csv`: 1-minute continuous contract data
- `{ticker}_5min.csv`: 5-minute continuous contract data
- Seamless price series with intelligent rollover points

### Analysis (`summary/` folder)
- `summary_check_monthly.png`: Monthly contracts availability
- `summary_check_quarterly.png`: Quarterly contracts availability
- `{ticker}_rolls.png`: Volume analysis and rollover charts
- `{ticker}_rolls.csv`: Rollover date records

## API Usage

This project uses the MOEX API through the `apimoex` and `moexalgo` libraries:
- **Rate Limiting**: Built-in delays and retry mechanisms with exponential backoff
- **Error Handling**: Comprehensive exception handling for network issues
- **Session Management**: Robust HTTP session configuration with urllib3 retry strategies
- **Circuit Breaker**: Automatic failure detection and recovery mechanisms

## Dependencies

- `pandas>=1.5.0` - Data manipulation and analysis
- `numpy>=1.21.0` - Numerical computations
- `matplotlib>=3.5.0` - Data visualization
- `requests>=2.28.0` - HTTP requests
- `apimoex>=1.2.0` - MOEX API client
- `moexalgo>=1.0.0` - Alternative MOEX API client
- `tqdm>=4.60.0` - Progress bars
- `urllib3>=1.26.0` - HTTP client utilities (for retry functionality)


## Error Handling

The system includes comprehensive error handling:
- **Network Issues**: Automatic retries with exponential backoff and circuit breaker patterns
- **API Limits**: Respectful delays between requests with random jitter
- **Data Quality**: File size validation and missing data detection
- **Progress Tracking**: Detailed success/failure reporting with real-time statistics
- **Session Resilience**: HTTP adapter configuration with connection pooling and retry strategies

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is open source. Please check the license file for details.

## Support

For issues and questions:
1. Check the existing issues in the repository
2. Create a new issue with detailed description
3. Include error logs and system information

## Changelog

- **v1.0**: Initial release with basic data downloading
- **v1.1**: Added continuous contract construction
- **v1.2**: Enhanced error handling and progress tracking
- **v1.3**: Added visualization and summary tools
- **v1.4**: Updated dependencies and improved documentation
